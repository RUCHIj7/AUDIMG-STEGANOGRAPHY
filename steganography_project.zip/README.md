# 🔐 Audio & Image Steganography Tool

A GUI-based Python application that allows users to **hide (encode)** and **reveal (decode)** secret messages in both **WAV audio** and **PNG image** files using steganography techniques. This is a simple yet effective tool for learning and demonstrating how steganography works in multimedia files.

... (truncated for brevity; full content included in the final file) ...
